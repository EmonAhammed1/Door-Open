<?php
/**
 * Settings → Door Open Intro.
 *
 * "Page behind the door" is WordPress's own homepage setting (Settings → Reading → Your homepage displays),
 * edited from here: the door plays over whatever the homepage is, so choosing the page and choosing the
 * homepage are the same thing. Saving here updates Reading, and changing Reading shows up here.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', 'doi_admin_menu' );
function doi_admin_menu() {
	add_options_page(
		__( 'Door Open Intro', 'door-open-intro' ),
		__( 'Door Open Intro', 'door-open-intro' ),
		'manage_options',
		'door-open-intro',
		'doi_render_settings_page'
	);
}

add_action( 'admin_init', 'doi_register_settings' );
function doi_register_settings() {
	register_setting(
		'doi_settings_group',
		DOI_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'doi_sanitize',
			'default'           => doi_defaults(),
		)
	);
}

function doi_sanitize( $in ) {
	$d  = doi_defaults();
	$in = is_array( $in ) ? $in : array();

	// Not stored in our option: it lives in WordPress's Reading settings (see file header).
	if ( isset( $in['front_page'] ) ) {
		doi_set_front_page( absint( $in['front_page'] ) );
	}

	$button = isset( $in['button'] ) ? sanitize_text_field( $in['button'] ) : '';

	return array(
		'enabled'  => empty( $in['enabled'] ) ? 0 : 1,
		'where'    => ( isset( $in['where'] ) && 'all' === $in['where'] ) ? 'all' : 'home',
		'once'     => empty( $in['once'] ) ? 0 : 1,
		'once_all' => empty( $in['once_all'] ) ? 0 : 1,
		'mobile'   => empty( $in['mobile'] ) ? 0 : 1,
		'skip'     => empty( $in['skip'] ) ? 0 : 1,
		'wordmark' => isset( $in['wordmark'] ) ? sanitize_text_field( $in['wordmark'] ) : $d['wordmark'],
		'tagline'  => isset( $in['tagline'] ) ? sanitize_textarea_field( $in['tagline'] ) : $d['tagline'],
		'button'   => '' !== $button ? $button : $d['button'],
		'caption'  => isset( $in['caption'] ) ? sanitize_text_field( $in['caption'] ) : $d['caption'],
	);
}

/**
 * @param int $page_id A published page, or 0 for "your latest posts".
 */
function doi_set_front_page( $page_id ) {
	if ( 0 === $page_id ) {
		update_option( 'show_on_front', 'posts' );
		return;
	}
	if ( 'page' !== get_post_type( $page_id ) || 'publish' !== get_post_status( $page_id ) ) {
		add_settings_error( DOI_OPTION, 'doi_bad_page', __( 'That page isn\'t published, so it can\'t be shown behind the door. Publish it first, then choose it again.', 'door-open-intro' ) );
		return;
	}
	if ( (int) get_option( 'page_for_posts' ) === $page_id ) {
		add_settings_error( DOI_OPTION, 'doi_posts_page', __( 'That page is your blog\'s Posts page, so it can\'t also be the page behind the door. Choose another page, or change the Posts page under Settings → Reading.', 'door-open-intro' ) );
		return;
	}
	update_option( 'page_on_front', $page_id );
	update_option( 'show_on_front', 'page' );
}

function doi_current_front_page() {
	return 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
}

/**
 * Right after installing, the homepage is usually still "your latest posts". Point that out where it's
 * relevant, until a page has been chosen.
 */
add_action( 'admin_notices', 'doi_setup_notice' );
function doi_setup_notice() {
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'dashboard' ), true ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( doi_current_front_page() ) {
		return;
	}
	printf(
		'<div class="notice notice-info"><p>%s <a href="%s">%s</a></p></div>',
		esc_html__( 'Door Open Intro: your homepage currently shows your latest posts, so that is what visitors will walk into.', 'door-open-intro' ),
		esc_url( admin_url( 'options-general.php?page=door-open-intro' ) ),
		esc_html__( 'Choose the page behind the door', 'door-open-intro' )
	);
}

function doi_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s       = doi_settings();
	$name    = DOI_OPTION;
	$front   = doi_current_front_page();
	$preview = add_query_arg( 'doi_preview', '1', home_url( '/' ) );
	?>
	<div class="wrap doi-admin">
		<style>
			.doi-admin .doi-hero{display:flex;gap:20px;align-items:center;margin:14px 0 6px;max-width:880px}
			.doi-admin .doi-hero img{width:220px;height:auto;border-radius:6px;box-shadow:0 4px 18px rgba(0,0,0,.12);flex:none}
			.doi-admin .doi-hero p{margin:0 0 8px;max-width:56ch;color:#50575e}
			.doi-admin .form-table th{width:220px}
			.doi-admin textarea{width:100%;max-width:420px}
			@media (max-width:640px){.doi-admin .doi-hero{flex-direction:column;align-items:flex-start}}
		</style>

		<h1><?php esc_html_e( 'Door Open Intro', 'door-open-intro' ); ?></h1>

		<div class="doi-hero">
			<img src="<?php echo esc_url( doi_image_url( 'desktop-lit.jpg' ) ); ?>" alt="">
			<div>
				<p><?php esc_html_e( 'Visitors arrive at the closed door. When they press the button, its engraving lights up from the centre, the doors swing open and they walk through into the page you choose below, which has already loaded behind the door.', 'door-open-intro' ); ?></p>
				<a class="button" href="<?php echo esc_url( $preview ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Preview on your site ↗', 'door-open-intro' ); ?></a>
			</div>
		</div>

		<form method="post" action="options.php">
			<?php settings_fields( 'doi_settings_group' ); ?>

			<h2><?php esc_html_e( 'Page behind the door', 'door-open-intro' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="doi-front-page"><?php esc_html_e( 'Visitors walk into', 'door-open-intro' ); ?></label></th>
					<td>
						<?php
						$dropdown = wp_dropdown_pages(
							array(
								'name'              => $name . '[front_page]',
								'id'                => 'doi-front-page',
								'selected'          => (int) $front,
								'show_option_none'  => esc_html__( '— Your latest posts —', 'door-open-intro' ),
								'option_none_value' => '0',
								'echo'              => 0,
							)
						);
						if ( $dropdown ) {
							echo $dropdown; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core-generated markup.
						} else {
							echo '<p>' . esc_html__( 'You have no published pages yet. Publish the page visitors should walk into, then choose it here.', 'door-open-intro' ) . '</p>';
						}
						?>
						<p class="description"><?php esc_html_e( 'This is your homepage; the door opens onto it. It is the same setting as Settings → Reading → "Your homepage displays", so changing it here updates it there too.', 'door-open-intro' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'When the door appears', 'door-open-intro' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Door intro', 'door-open-intro' ); ?></th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[enabled]" value="1" <?php checked( $s['enabled'], 1 ); ?>> <?php esc_html_e( 'Show the door to visitors', 'door-open-intro' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Where', 'door-open-intro' ); ?></th>
					<td>
						<fieldset>
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[where]" value="home" <?php checked( $s['where'], 'home' ); ?>> <?php esc_html_e( 'On the homepage', 'door-open-intro' ); ?></label><br>
							<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[where]" value="all" <?php checked( $s['where'], 'all' ); ?>> <?php esc_html_e( 'On every page (the door opens onto whichever page they arrived at)', 'door-open-intro' ); ?></label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Repeat visits', 'door-open-intro' ); ?></th>
					<td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[once]" value="1" <?php checked( $s['once'], 1 ); ?>> <?php esc_html_e( 'Only once per visit in the same tab (a new tab shows it again)', 'door-open-intro' ); ?></label><br>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[once_all]" value="1" <?php checked( $s['once_all'], 1 ); ?>> <?php esc_html_e( 'Only once until the visitor closes their browser, across all tabs', 'door-open-intro' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Phones', 'door-open-intro' ); ?></th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[mobile]" value="1" <?php checked( $s['mobile'], 1 ); ?>> <?php esc_html_e( 'Show on phones too', 'door-open-intro' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Skip', 'door-open-intro' ); ?></th>
					<td>
						<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[skip]" value="1" <?php checked( $s['skip'], 1 ); ?>> <?php esc_html_e( 'Show a small "Skip intro" link', 'door-open-intro' ); ?></label>
						<p class="description"><?php esc_html_e( 'Pressing Esc always skips.', 'door-open-intro' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Text on the door', 'door-open-intro' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="doi-wordmark"><?php esc_html_e( 'Name', 'door-open-intro' ); ?></label></th>
					<td><input type="text" class="regular-text" id="doi-wordmark" name="<?php echo esc_attr( $name ); ?>[wordmark]" value="<?php echo esc_attr( $s['wordmark'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="doi-tagline"><?php esc_html_e( 'Tagline', 'door-open-intro' ); ?></label></th>
					<td>
						<textarea id="doi-tagline" rows="2" name="<?php echo esc_attr( $name ); ?>[tagline]"><?php echo esc_textarea( $s['tagline'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One line per row. Leave empty for no tagline.', 'door-open-intro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="doi-button"><?php esc_html_e( 'Button', 'door-open-intro' ); ?></label></th>
					<td><input type="text" class="regular-text" id="doi-button" name="<?php echo esc_attr( $name ); ?>[button]" value="<?php echo esc_attr( $s['button'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="doi-caption"><?php esc_html_e( 'Under the button', 'door-open-intro' ); ?></label></th>
					<td><input type="text" class="regular-text" id="doi-caption" name="<?php echo esc_attr( $name ); ?>[caption]" value="<?php echo esc_attr( $s['caption'] ); ?>"></td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
