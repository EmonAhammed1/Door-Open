<?php
/**
 * Plugin Name:       Door Open Intro
 * Plugin URI:        https://github.com/EmonAhammed1/Door-Open
 * Description:       A full-screen DRUMI threshold: the door's engraving ignites, the doors swing open and the visitor walks through into your page, already loaded behind it.
 * Version:           4.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Door Open
 * License:           GPL-2.0-or-later
 * Text Domain:       door-open-intro
 */

defined( 'ABSPATH' ) || exit;

define( 'DOI_VERSION', '4.1.0' );
define( 'DOI_DIR', plugin_dir_path( __FILE__ ) );
define( 'DOI_URL', plugin_dir_url( __FILE__ ) );
define( 'DOI_OPTION', 'doi_intro' );

require_once DOI_DIR . 'includes/admin.php';

function doi_defaults() {
	return array(
		'enabled'  => 1,
		'where'    => 'home', // 'home' | 'all'
		'once'     => 0, // once per tab (sessionStorage)
		'once_all' => 0, // once per browser session, across all tabs (session cookie)
		'mobile'   => 1,
		'skip'     => 1,
		'wordmark' => 'DRUMI',
		'tagline'  => "A sanctuary for your dreams.\nA journey back to yourself.",
		'button'   => 'Join the journey',
		'caption'  => 'Step into your inner world',
	);
}

function doi_settings() {
	$saved = get_option( DOI_OPTION, array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), doi_defaults() );
}

function doi_image_url( $name ) {
	return DOI_URL . 'assets/door/' . $name;
}

/**
 * Page builders render the page inside an iframe while you edit it; the door must never cover that.
 */
function doi_in_builder_preview() {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only checks of builder query flags.
	foreach ( array( 'elementor-preview', 'et_fb', 'fl_builder', 'ct_builder', 'vc_editable', 'brizy-edit-iframe', 'bricks' ) as $flag ) {
		if ( isset( $_GET[ $flag ] ) ) {
			return true;
		}
	}
	// phpcs:enable
	if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->preview ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
		return true;
	}
	return false;
}

/**
 * Whether this front-end request gets the door. Decided once, after the main query has run.
 * `?doi_preview=1` shows it even when disabled or already seen, for checking your setup.
 */
function doi_should_play() {
	static $decision = null;
	if ( null !== $decision ) {
		return $decision;
	}
	$decision = false;

	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || is_feed() || is_robots() || is_embed() || is_trackback() || is_customize_preview() || is_preview() || is_404() ) {
		return false;
	}
	if ( doi_in_builder_preview() ) {
		return false;
	}

	$s      = doi_settings();
	$forced = doi_is_forced();
	if ( ! $s['enabled'] && ! $forced ) {
		return false;
	}
	if ( 'home' === $s['where'] && ! is_front_page() && ! $forced ) {
		return false;
	}

	$decision = true;
	return true;
}

function doi_is_forced() {
	return isset( $_GET['doi_preview'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
}

/**
 * Everything the browser-side script needs. Text is inserted with textContent, never as HTML.
 */
function doi_client_config() {
	$s     = doi_settings();
	$lines = array_values( array_filter( array_map( 'trim', explode( "\n", (string) $s['tagline'] ) ), 'strlen' ) );
	return array(
		'idle'      => doi_image_url( 'desktop-idle.jpg' ),
		'lit'       => doi_image_url( 'desktop-lit.jpg' ),
		'phoneIdle' => doi_image_url( 'phone-idle.jpg' ),
		'phoneLit'  => doi_image_url( 'phone-lit.jpg' ),
		'wordmark'  => (string) $s['wordmark'],
		'tagline'   => $lines,
		'button'    => (string) $s['button'],
		'caption'   => (string) $s['caption'],
		'skip'      => (bool) $s['skip'],
		'skipLabel' => __( 'Skip intro', 'door-open-intro' ),
		'once'        => (bool) $s['once'],
		'onceBrowser' => (bool) $s['once_all'],
		'cookiePath'  => defined( 'COOKIEPATH' ) ? COOKIEPATH : '/',
	);
}

add_action( 'wp_enqueue_scripts', 'doi_enqueue' );
function doi_enqueue() {
	if ( ! doi_should_play() ) {
		return;
	}
	// `display=block` keeps the engraved wordmark from flashing in a fallback face.
	wp_enqueue_style( 'doi-fonts', 'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500&family=Cormorant+Garamond:ital,wght@1,400&display=block', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceVersion.MissingVersion
	wp_enqueue_style( 'doi-intro', DOI_URL . 'assets/intro.css', array(), DOI_VERSION );
	wp_enqueue_script( 'doi-intro', DOI_URL . 'assets/intro.js', array(), DOI_VERSION, true );
	wp_add_inline_script( 'doi-intro', 'window.DOI_CONFIG = ' . wp_json_encode( doi_client_config() ) . ';', 'before' );
}

/**
 * Runs in <head>, before anything paints: decides whether this visit plays the door (once-per-visit and
 * phone settings are checked in the browser, so full-page caches stay correct), and hides the page
 * behind a still of the closed door until the intro script takes over.
 */
add_action( 'wp_head', 'doi_print_head', 1 );
function doi_print_head() {
	if ( ! doi_should_play() ) {
		return;
	}
	$s    = doi_settings();
	$idle = doi_image_url( 'desktop-idle.jpg' );
	$gate = array(
		'once'    => (bool) $s['once'],
		'onceAll' => (bool) $s['once_all'],
		'mobile'  => (bool) $s['mobile'],
		'forced'  => doi_is_forced(),
	);
	// The loading still has to match the live door exactly, so these rules mirror intro.js: portrait screens
	// (≤ 3:4, `pickSet`) use the phone photographs; either photograph is fitted to 760px of its width
	// (`fitWidth`) instead of `cover` when the screen is too narrow for its door, with a blurred copy above and below.
	$phone     = doi_image_url( 'phone-idle.jpg' );
	$pseudo    = 'content:"";position:absolute;top:0;right:0;bottom:0;left:0;background:50% 50%/cover no-repeat';
	?>
<link rel="preload" as="image" href="<?php echo esc_url( $idle ); ?>" media="(min-aspect-ratio: 3/4)">
<link rel="preload" as="image" href="<?php echo esc_url( doi_image_url( 'desktop-lit.jpg' ) ); ?>" media="(min-aspect-ratio: 3/4)">
<link rel="preload" as="image" href="<?php echo esc_url( $phone ); ?>" media="(max-aspect-ratio: 3/4)">
<link rel="preload" as="image" href="<?php echo esc_url( doi_image_url( 'phone-lit.jpg' ) ); ?>" media="(max-aspect-ratio: 3/4)">
<style id="doi-critical">
html.doi-on,html.doi-on body{overflow:hidden!important}
html.doi-on:not(.doi-ready) body{visibility:hidden}
.doi-cover{display:none}
html.doi-on .doi-cover{display:block;visibility:visible;position:fixed;top:0;right:0;bottom:0;left:0;z-index:2147483000;overflow:hidden;background:#dcc8a8 url("<?php echo esc_url( $idle ); ?>") 50% 50%/cover no-repeat}
html.doi-on .doi-cover::before,html.doi-on .doi-cover::after{<?php echo $pseudo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static CSS. ?>;display:none}
html.doi-on .doi-cover::before{filter:blur(22px) brightness(.94);transform:scale(1.1)}
@media (max-aspect-ratio:760/941){
html.doi-on .doi-cover{background-image:none}
html.doi-on .doi-cover::before,html.doi-on .doi-cover::after{display:block;background-image:url("<?php echo esc_url( $idle ); ?>")}
html.doi-on .doi-cover::after{background-size:calc(100vw * 1672 / 760) auto}
}
@media (max-aspect-ratio:3/4){
html.doi-on .doi-cover{background-image:url("<?php echo esc_url( $phone ); ?>")}
html.doi-on .doi-cover::before,html.doi-on .doi-cover::after{display:none}
}
@media (max-aspect-ratio:760/1671){
html.doi-on .doi-cover{background-image:none}
html.doi-on .doi-cover::before,html.doi-on .doi-cover::after{display:block;background-image:url("<?php echo esc_url( $phone ); ?>")}
html.doi-on .doi-cover::after{background-size:calc(100vw * 941 / 760) auto}
}
</style>
<script id="doi-gate">
(function(d,w,g){var h=d.documentElement;
try{if(g.once&&!g.forced&&w.sessionStorage.getItem('doi_seen'))return}catch(e){}
if(g.onceAll&&!g.forced&&/(?:^|;\s*)doi_seen=1(?:;|$)/.test(d.cookie))return;
if(!g.mobile&&!g.forced&&w.matchMedia&&w.matchMedia('(max-width: 767px)').matches)return;
h.classList.add('doi-on');
w.setTimeout(function(){if(!h.classList.contains('doi-ready'))h.classList.remove('doi-on')},10000);
})(document,window,<?php echo wp_json_encode( $gate ); ?>);
</script>
	<?php
}

/**
 * The closed-door still, first thing in <body>, so the very first paint is the door and never the page.
 * Themes without wp_body_open get it at the end of <body>; until then the page is hidden by the critical CSS.
 */
add_action( 'wp_body_open', 'doi_print_cover', 1 );
add_action( 'wp_footer', 'doi_print_cover', 1 );
function doi_print_cover() {
	static $printed = false;
	if ( $printed || ! doi_should_play() ) {
		return;
	}
	$printed = true;
	echo '<div class="doi-cover" aria-hidden="true"></div>' . "\n";
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'doi_action_links' );
function doi_action_links( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=door-open-intro' ) ) . '">' . esc_html__( 'Settings', 'door-open-intro' ) . '</a>' );
	return $links;
}
